function neural_assemble_spa(test_data,net,stimulus,T0)

T1 = T0/2;N_neuron = size(test_data{1,1}.Zt,1);L = size(test_data,2);

%% reaction time
clear RT_mu;clear RT_std;clear correction_radio;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time;
  iden_time = net.iden_t(m1,:);
  correction_radio(m1,1) = sum(double(iden_time>=0))/length(iden_time);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end

errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

clear h;clear p;
[h,p] = ttest2(net.iden_t(1,:),net.iden_t(2,:));p

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['c = ',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);
for n1 = 1:size(stimulus,2)
    clear aa;
    aa = ['correction radio upon c = ',num2str(n1),' is ',num2str(correction_radio(n1))];
    disp(aa);
end

%% Calculting downstream neural spiking rates for each situation

% Stimulus-induced responses of three groups of ex. neurons
j = 1;clear Z_cout_sti;clear Zleft_cout_sti;clear Zright_cout_sti;
% cout_sti for neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    Z_cout_sti(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0-T1) = 1;
          end
      end
    end
    Zleft_cout_sti(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0-T1) = 1;
          end  
      end
    end
    Zright_cout_sti(:,:,l,l_style) = Zright;
    end
    j = 1+j;
end
% 
j = 1;clear Z_cout_pre;clear Zleft_cout_pre;clear Zright_cout_pre;
% cout_pre for neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zt(n,t) == 1
             Z(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Z_cout_pre(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Zleft_cout_pre(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0) = 1;
          end  
      end
    end
    Zright_cout_pre(:,:,l,l_style) = Zright;
   end
j = 1+j;
end


% neural spiking rates
Z_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            
        end
    end
  end
 end
end

Z_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
%% save and load neural spiking rates if necessary
% save('Z_rate_pe','Z_rate_pe');save('Z_rate_real','Z_rate_real');save('Z_cout_sti','Z_cout_sti');save('Z_cout_pre','Z_cout_pre');save('Zleft_rate_pe','Zleft_rate_pe');save('Zleft_rate_real','Zleft_rate_real');save('Zleft_cout_sti','Zleft_cout_sti');save('Zleft_cout_pre','Zleft_cout_pre');save('Zright_rate_pe','Zright_rate_pe');save('Zright_rate_real','Zright_rate_real');save('Zright_cout_sti','Zright_cout_sti');save('Zright_cout_pre','Zright_cout_pre');

% aa = load('Z_rate_pe');Z_rate_pe = aa.Z_rate_pe; aa = load('Z_rate_real');Z_rate_real = aa.Z_rate_real; aa = load('Z_cout_sti');Z_cout_sti = aa.Z_cout_sti; aa = load('Z_cout_pre');Z_cout_pre = aa.Z_cout_pre;aa = load('Zleft_rate_pe');Zleft_rate_pe = aa.Zleft_rate_pe;aa = load('Zleft_rate_real');Zleft_rate_real = aa.Zleft_rate_real;aa = load('Zleft_cout_sti');Zleft_cout_sti = aa.Zleft_cout_sti;aa = load('Zleft_cout_pre');Zleft_cout_pre = aa.Zleft_cout_pre;aa = load('Zright_rate_pe');Zright_rate_pe = aa.Zright_rate_pe;aa = load('Zright_rate_real');Zright_rate_real = aa.Zright_rate_real;aa = load('Zright_cout_sti');Zright_cout_sti = aa.Zright_cout_sti;aa = load('Zright_cout_pre');Zright_cout_pre = aa.Zright_cout_pre;
%% neural variability quenching

% neural responding variability of neural population
Zleft_rate_pe_popu = sum(Zleft_rate_pe,1);
Zright_rate_pe_popu = sum(Zright_rate_pe,1);
Z_rate_pe_popu = sum(Z_rate_pe,1);
Zleft_rate_real_popu =  sum(Zleft_rate_real,1);
Zright_rate_real_popu = sum(Zright_rate_real,1);
Z_rate_real_popu = sum(Z_rate_real,1);

clear Zleft_std_real;clear Zright_std_real;clear Z_std_real;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_real(1,t,l_style) = mean(Zleft_rate_real_popu(1,t,:,l_style));
   Zleft_std_real(1,t,l_style) = std(Zleft_rate_real_popu(1,t,:,l_style));
   Fanoleft_real(1,t,l_style) = (Zleft_std_real(1,t,l_style)^2)/Zleft_mean_real(1,t,l_style);
   Zright_mean_real(1,t,l_style) = mean(Zright_rate_real_popu(1,t,:,l_style));
   Zright_std_real(1,t,l_style) = std(Zright_rate_real_popu(1,t,:,l_style));
   Fanoright_real(1,t,l_style) = (Zright_std_real(1,t,l_style)^2)/Zright_mean_real(1,t,l_style);
   Z_mean_real(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_std_real(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));
   FanoZ_real(1,t,l_style) = (Z_std_real(1,t,l_style)^2)/Z_mean_real(1,t,l_style);
  end
end
clear Zleft_std_pe;clear Zright_std_pe;clear Z_std_pe;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_pe(1,t,l_style) = mean(Zleft_rate_pe_popu(1,t,:,l_style));
   Zleft_std_pe(1,t,l_style) = std(Zleft_rate_pe_popu(1,t,:,l_style));
   Fanoleft_pe(1,t,l_style) = (Zleft_std_pe(1,t,l_style)^2)/Zleft_mean_pe(1,t,l_style);
   Zright_mean_pe(1,t,l_style) = mean(Zright_rate_pe_popu(1,t,:,l_style));
   Zright_std_pe(1,t,l_style) = std(Zright_rate_pe_popu(1,t,:,l_style));
   Fanoright_pe(1,t,l_style) = (Zright_std_pe(1,t,l_style)^2)/Zright_mean_pe(1,t,l_style);
   Z_mean_pe(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
   Z_std_pe(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
   FanoZ_pe(1,t,l_style) = (Z_std_pe(1,t,l_style)^2)/Z_mean_pe(1,t,l_style);
  end
end

% plot ex. neural variability
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zleft_std_pe,3)
    y1 = [y1,Zleft_std_pe(:,:,n1),Zleft_std_real(:,:,n1)];
end
y2 = [];
for n1 = 1:size(Zright_std_pe,3)
    y2 = [y2,Zright_std_pe(:,:,n1),Zright_std_real(:,:,n1)];
end
y3 = [];
for n1 = 1:size(Z_std_pe,3)
    y3 = [y3,Z_std_pe(:,:,n1),Z_std_real(:,:,n1)];
end
y_bottom = 0.95*min([min(y1),min(y2),min(y3)]);
y_top = 1.05*max([max(y1),max(y2),max(y3)]);

figure;
plot(x,y1,'color',[0.8,0.8,0.8]);hold on;
plot(x,y2,'color',[0.5,0.5,0.5]);hold on;
plot(x,y3,'color',[0.3,0.3,0.3]);hold on;
ylim([y_bottom,y_top]);ylabel('SD');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[y_bottom,y_top],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[y_bottom,y_top],'--','color',[0.8,0.8,0.8]);hold on;
end

%% neural sparse responses of three neural groups

clear sparseness_Z;clear sparseness_Zleft;clear sparseness_Zright;
for n_neuron = 1:size(Z_cout_sti,1)% for each neuron in the 3rd ex. group
    % a1 is neural spikes in 1st situation
    a1 = Z_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Z_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Z_rate_sti(1) = mean(mean(a1,2),3);
    Z_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Z_rate_sti)>0
       sparseness_Z(n_neuron) = (mean(Z_rate_sti)^2)/mean(Z_rate_sti.^2);
    else
       sparseness_Z(n_neuron) = 0;
    end
end
for n_neuron = 1:size(Zleft_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zleft_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zleft_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zleft_rate_sti(1) = mean(mean(a1,2),3);
    Zleft_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zleft_rate_sti)>0
       sparseness_Zleft(n_neuron) = (mean(Zleft_rate_sti)^2)/mean(Zleft_rate_sti.^2);
    else
       sparseness_Zleft(n_neuron) = 0;
    end
end
clear sparseness_Zright;
for n_neuron = 1:size(Zright_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zright_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zright_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zright_rate_sti(1) = mean(mean(a1,2),3);
    Zright_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zright_rate_sti)>0
       sparseness_Zright(n_neuron) = (mean(Zright_rate_sti)^2)/mean(Zright_rate_sti.^2);
    else
       sparseness_Zright(n_neuron) = 0;
    end
end
% plot neural sparseness of three neural groups
clear a1;
xbin = 0:0.2:1;
[a0,b0] = hist((1-sparseness_Zleft(:)),xbin);
a1(:,1) = a0./sum(a0);
[a0,b0] = hist((1-sparseness_Zright(:)),xbin);
a1(:,2) = a0./sum(a0);
[a0,b0] = hist((1-sparseness_Z(:)),xbin);
a1(:,3) = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'neural group ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
legend(aa);
ylim([0,1.1]);title('Neural sparseness');

end