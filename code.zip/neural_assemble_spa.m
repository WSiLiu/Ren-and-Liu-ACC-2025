function neural_assemble_spa(test_data,net,stimulus,T0)

T1 = T0/2;N_neuron = size(test_data{1,1}.Zt,1);L = size(test_data,2);

%% reaction time
clear RT_mu;clear RT_std;clear correction_radio;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time;
  iden_time = net.iden_t(m1,:);
  correction_radio(m1,1) = sum(double(iden_time>=0))/length(iden_time);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end

errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

clear h;clear p;
[h,p] = ttest2(net.iden_t(1,:),net.iden_t(2,:));p

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['c = ',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);
for n1 = 1:size(stimulus,2)
    clear aa;
    aa = ['correction radio upon c = ',num2str(n1),' is ',num2str(correction_radio(n1))];
    disp(aa);
end

%% Calculting downstream neural spiking rates for each situation

% Stimulus-induced responses of three groups of ex. neurons
j = 1;clear Z_cout_sti;clear Zleft_cout_sti;clear Zright_cout_sti;
% cout_sti for neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    Z_cout_sti(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0-T1) = 1;
          end
      end
    end
    Zleft_cout_sti(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0-T1) = 1;
          end  
      end
    end
    Zright_cout_sti(:,:,l,l_style) = Zright;
    end
    j = 1+j;
end
% 
j = 1;clear Z_cout_pre;clear Zleft_cout_pre;clear Zright_cout_pre;
% cout_pre for neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zt(n,t) == 1
             Z(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Z_cout_pre(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Zleft_cout_pre(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0) = 1;
          end  
      end
    end
    Zright_cout_pre(:,:,l,l_style) = Zright;
   end
j = 1+j;
end


% neural spiking rates
Z_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            
        end
    end
  end
 end
end

Z_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zleft_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
%% save and load neural spiking rates if necessary
% save('Z_rate_pe','Z_rate_pe');save('Z_rate_real','Z_rate_real');save('Z_cout_sti','Z_cout_sti');save('Z_cout_pre','Z_cout_pre');save('Zleft_rate_pe','Zleft_rate_pe');save('Zleft_rate_real','Zleft_rate_real');save('Zleft_cout_sti','Zleft_cout_sti');save('Zleft_cout_pre','Zleft_cout_pre');save('Zright_rate_pe','Zright_rate_pe');save('Zright_rate_real','Zright_rate_real');save('Zright_cout_sti','Zright_cout_sti');save('Zright_cout_pre','Zright_cout_pre');

% aa = load('Z_rate_pe');Z_rate_pe = aa.Z_rate_pe; aa = load('Z_rate_real');Z_rate_real = aa.Z_rate_real; aa = load('Z_cout_sti');Z_cout_sti = aa.Z_cout_sti; aa = load('Z_cout_pre');Z_cout_pre = aa.Z_cout_pre;aa = load('Zleft_rate_pe');Zleft_rate_pe = aa.Zleft_rate_pe;aa = load('Zleft_rate_real');Zleft_rate_real = aa.Zleft_rate_real;aa = load('Zleft_cout_sti');Zleft_cout_sti = aa.Zleft_cout_sti;aa = load('Zleft_cout_pre');Zleft_cout_pre = aa.Zleft_cout_pre;aa = load('Zright_rate_pe');Zright_rate_pe = aa.Zright_rate_pe;aa = load('Zright_rate_real');Zright_rate_real = aa.Zright_rate_real;aa = load('Zright_cout_sti');Zright_cout_sti = aa.Zright_cout_sti;aa = load('Zright_cout_pre');Zright_cout_pre = aa.Zright_cout_pre;
%% neural variability quenching
% neural spiking complex
[Zright_popucomplex_sti,Zright_popucomplex_pre] = neural_groups_spiking_complex(Zright_cout_sti,Zright_cout_pre);
[Zleft_popucomplex_sti,Zleft_popucomplex_pre] = neural_groups_spiking_complex(Zleft_cout_sti,Zleft_cout_pre);
[Z_popucomplex_sti,Z_popucomplex_pre] = neural_groups_spiking_complex(Z_cout_sti,Z_cout_pre);

clear whole_compex;
whole_compex = [Zright_popucomplex_sti(:);Zright_popucomplex_pre(:);Zleft_popucomplex_sti(:);Zleft_popucomplex_pre(:);Z_popucomplex_sti(:);Z_popucomplex_pre(:)];
top = 1.05*max(whole_compex(:));bottom = 0.95*min(whole_compex(:));
for n_simulation = 1:size(Zright_popucomplex_sti,2)
    figure;
    x = [1,4];
    a1 = [Zright_popucomplex_pre(n_simulation),Zright_popucomplex_sti(n_simulation)];
    plot(x,a1,'o-','MarkerSize',15,'Color',[0.2,0.2,0.2]);hold on;
    a2 = [Zleft_popucomplex_pre(n_simulation),Zleft_popucomplex_sti(n_simulation)];
    plot(x,a2,'o-','MarkerSize',15,'Color',[0.4,0.4,0.4]);hold on;
    a3 = [Z_popucomplex_pre(n_simulation),Z_popucomplex_sti(n_simulation)];
    plot(x,a3,'o-','MarkerSize',15,'Color',[0.6,0.6,0.6]);hold on;
    legend('1st group','2nd group','3rd group');
    set(gca,'xlim',[0,5],'XTick',[1,2,3,4],'xticklabel',{'pre-stimulus','','','post-stimulus'},'ylim',[bottom,top]);
end

% responding variability of neural population
Zleft_rate_pe_popu = sum(Zleft_rate_pe,1);
Zright_rate_pe_popu = sum(Zright_rate_pe,1);
Z_rate_pe_popu = sum(Z_rate_pe,1);
Zleft_rate_real_popu =  sum(Zleft_rate_real,1);
Zright_rate_real_popu = sum(Zright_rate_real,1);
Z_rate_real_popu = sum(Z_rate_real,1);

clear Zleft_std_real;clear Zright_std_real;clear Z_std_real;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_real(1,t,l_style) = mean(Zleft_rate_real_popu(1,t,:,l_style));
   Zleft_std_real(1,t,l_style) = std(Zleft_rate_real_popu(1,t,:,l_style));
   Fanoleft_real(1,t,l_style) = (Zleft_std_real(1,t,l_style)^2)/Zleft_mean_real(1,t,l_style);
   Zright_mean_real(1,t,l_style) = mean(Zright_rate_real_popu(1,t,:,l_style));
   Zright_std_real(1,t,l_style) = std(Zright_rate_real_popu(1,t,:,l_style));
   Fanoright_real(1,t,l_style) = (Zright_std_real(1,t,l_style)^2)/Zright_mean_real(1,t,l_style);
   Z_mean_real(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_std_real(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));
   FanoZ_real(1,t,l_style) = (Z_std_real(1,t,l_style)^2)/Z_mean_real(1,t,l_style);
  end
end
clear Zleft_std_pe;clear Zright_std_pe;clear Z_std_pe;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_pe(1,t,l_style) = mean(Zleft_rate_pe_popu(1,t,:,l_style));
   Zleft_std_pe(1,t,l_style) = std(Zleft_rate_pe_popu(1,t,:,l_style));
   Fanoleft_pe(1,t,l_style) = (Zleft_std_pe(1,t,l_style)^2)/Zleft_mean_pe(1,t,l_style);
   Zright_mean_pe(1,t,l_style) = mean(Zright_rate_pe_popu(1,t,:,l_style));
   Zright_std_pe(1,t,l_style) = std(Zright_rate_pe_popu(1,t,:,l_style));
   Fanoright_pe(1,t,l_style) = (Zright_std_pe(1,t,l_style)^2)/Zright_mean_pe(1,t,l_style);
   Z_mean_pe(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
   Z_std_pe(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
   FanoZ_pe(1,t,l_style) = (Z_std_pe(1,t,l_style)^2)/Z_mean_pe(1,t,l_style);
  end
end

% plot variability of spikes 1st ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zleft_std_pe,3)
    y1 = [y1,Zleft_std_pe(:,:,n1),Zleft_std_real(:,:,n1)];
end
y2 = [];
for n1 = 1:size(Zright_std_pe,3)
    y2 = [y2,Zright_std_pe(:,:,n1),Zright_std_real(:,:,n1)];
end
y3 = [];
for n1 = 1:size(Z_std_pe,3)
    y3 = [y3,Z_std_pe(:,:,n1),Z_std_real(:,:,n1)];
end
y_bottom = 0.95*min([min(y1),min(y2),min(y3)]);
y_top = 1.05*max([max(y1),max(y2),max(y3)]);

figure;
plot(x,y1,'color',[0.8,0.8,0.8]);hold on;
plot(x,y2,'color',[0.5,0.5,0.5]);hold on;
plot(x,y3,'color',[0.3,0.3,0.3]);hold on;
ylim([y_bottom,y_top]);ylabel('SD');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[y_bottom,y_top],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[y_bottom,y_top],'--','color',[0.8,0.8,0.8]);hold on;
end

%% neural sparse responses of three neural groups

clear sparseness_Z;clear sparseness_Zleft;clear sparseness_Zright;
for n_neuron = 1:size(Z_cout_sti,1)% for each neuron in the 3rd ex. group
    % a1 is neural spikes in 1st situation
    a1 = Z_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Z_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Z_rate_sti(1) = mean(mean(a1,2),3);
    Z_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Z_rate_sti)>0
       sparseness_Z(n_neuron) = (mean(Z_rate_sti)^2)/mean(Z_rate_sti.^2);
    else
       sparseness_Z(n_neuron) = 0;
    end
end
for n_neuron = 1:size(Zleft_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zleft_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zleft_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zleft_rate_sti(1) = mean(mean(a1,2),3);
    Zleft_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zleft_rate_sti)>0
       sparseness_Zleft(n_neuron) = (mean(Zleft_rate_sti)^2)/mean(Zleft_rate_sti.^2);
    else
       sparseness_Zleft(n_neuron) = 0;
    end
end
clear sparseness_Zright;
for n_neuron = 1:size(Zright_cout_sti,1)% for each neuron in the 1st ex. group
    % a1 is neural spikes in 1st situation
    a1 = Zright_cout_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Zright_cout_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Zright_rate_sti(1) = mean(mean(a1,2),3);
    Zright_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Zright_rate_sti)>0
       sparseness_Zright(n_neuron) = (mean(Zright_rate_sti)^2)/mean(Zright_rate_sti.^2);
    else
       sparseness_Zright(n_neuron) = 0;
    end
end
% plot neural sparseness of three neural groups
clear a1;
xbin = 0:0.2:1;
[a0,b0] = hist((1-sparseness_Zleft(:)),xbin);
a1(:,1) = a0./sum(a0);
[a0,b0] = hist((1-sparseness_Zright(:)),xbin);
a1(:,2) = a0./sum(a0);
[a0,b0] = hist((1-sparseness_Z(:)),xbin);
a1(:,3) = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'neural group ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
legend(aa);
ylim([0,1.1]);title('Neural sparseness');

%% PCA of ex. neural responses over different situations
neuralpopulation_rate = []; % neural responses at each time step is variable
for n1 = 1:size(Z_rate_real,4) % over situations
    for t = 1:size(Z_rate_real,2) % for each time step
        % neural population is averaged over simulation
        clear neural_responses0;
        neural_responses0 = [mean(Zleft_rate_real(:,t,:,n1),3)',mean(Zright_rate_real(:,t,:,n1),3)',mean(Z_rate_real(:,t,:,n1),3)'];

        neuralpopulation_rate = [neuralpopulation_rate;neural_responses0];
    end
end
clear Sigma;
Sigma = cov(neuralpopulation_rate); % covariance matrix of neural responses

[COEFF, SCORE, latent] = pca(neuralpopulation_rate); % COEFF is the coefficient in PCA
% novel variables are neuralpopulation_rate*COEFF describe the responses of
% the network at a given time step
save('COEFF','COEFF');
contri_intergra = sum(latent(1:3))/sum(latent)

PCA_tem_real0 = [];
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(Z_rate_real,3) % for each simulation
        for t = 1:size(Z_rate_real,2) % for each time step
           clear neural_responses0;
           neural_responses0 = [Zleft_rate_real(:,t,n2,n1)',Zright_rate_real(:,t,n2,n1)',Z_rate_real(:,t,n2,n1)'];
           PCA_tem_real0(:,t,n1,n2) = (neural_responses0 * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe0 = [];
for n1 = 1:size(Z_rate_pe,4) % for each situation
    for n2 = 1:size(Z_rate_pe,3) % for each simulation
        for t = 1:size(Z_rate_pe,2) % for each time step
           clear neural_responses0;
           neural_responses0 = [Zleft_rate_pe(:,t,n2,n1)',Zright_rate_pe(:,t,n2,n1)',Z_rate_pe(:,t,n2,n1)'];
           PCA_tem_pe0(:,t,n1,n2) = (neural_responses0 * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe = mean(PCA_tem_pe0,4);
PCA_tem_real = mean(PCA_tem_real0,4);
clear PCA_tem;
for n1 = 1:size(Z_rate_real,4) % for each situation
    PCA_tem(:,:,n1) = [PCA_tem_pe(:,:,n1),PCA_tem_real(:,:,n1)];
end
d0 = 0.48/size(PCA_tem,2)*[1 1 1];
figure;
for n1 = 1:size(Z_rate_real,4) % for each situation
    for t = 1:size(PCA_tem,2)-1
    x1 = PCA_tem(1,t,n1);x2 = PCA_tem(1,t+1,n1);
    x = [x1 x2];
    y1 = PCA_tem(2,t,n1);y2 = PCA_tem(2,t+1,n1);
    y = [y1 y2];
    z1 = PCA_tem(3,t,n1);z2 = PCA_tem(3,t+1,n1);
    z = [z1 z2];
    if t<=size(PCA_tem,2)/2 
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the pre-stimulus duration
        plot3(x1, y1, z1,'o','Markersize',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    else
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the stimulus-presented duration
        plot3(x1, y1, z1,'o','Markersize',10,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    end
    plot3(x, y, z,'-','LineWidth',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t);hold on;
    end
end
grid on;
xlabel('PC1');ylabel('PC2');zlabel('PC3');

%% For downstream 3 ex. neural groups, their interactions are calculated through Pearson correlation coefficient

% interactions between pre-stimulus and stimulus-induced ex. neural responses

% X are stimulus-presented 1st ex. neural responses 
% Y are pre-stimulus 1st ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Zleft_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Zleft_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 1st ex. neural responses');

% X are stimulus-presented 2nd ex. neural responses 
% Y are pre-stimulus 2nd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Zright_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Zright_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 2nd ex. neural responses');

% X are stimulus-presented 3rd ex. neural responses 
% Y are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced 3rd ex. neural responses');

% interactions between stimulus-induced 1st and 2nd ex. neural responses
% X are stimulus-presented 1st ex. neural responses
% X1 are pre-stimulus 1st ex. neural responses
% Y are stimulus-presented 2nd ex. neural responses
% Y1 are pre-stimulus 2nd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 1st ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zleft_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 1st ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zleft_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Zright_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Zright_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 1st and 2nd ex. neural responses');


% interactions between stimulus-induced 2nd and 3rd ex. neural responses
% X are stimulus-presented 2nd ex. neural responses
% X1 are pre-stimulus 2nd ex. neural responses
% Y are stimulus-presented 3rd ex. neural responses
% Y1 are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zright_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zright_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 3rd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Z_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 3rd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Z_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 2nd and 3rd ex. neural responses');


% interactions between stimulus-induced 1st and 3rd ex. neural responses
% X are stimulus-presented 1st ex. neural responses
% X1 are pre-stimulus 1st ex. neural responses
% Y are stimulus-presented 3rd ex. neural responses
% Y1 are pre-stimulus 3rd ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal1;clear Zpe1;
        clear Zreal2;clear Zpe2;
        % Zreal1 are the temporal 2nd ex. neural populational responses in stimulus-presented duration
        Zreal1 = sum(Zleft_rate_real(:,t,:,l_style),1);Zreal1 = Zreal1(:);
        % Zpe1 are the temporal 2nd ex. neural populational responses in pre-stimulus duration
        Zpe1 = sum(Zleft_rate_pe(:,t,:,l_style),1);Zpe1 = Zpe1(:);
        % Zreal2 are the temporal 3rd ex. neural populational responses in stimulus-presented duration
        Zreal2 = sum(Z_rate_real(:,t,:,l_style),1);Zreal2 = Zreal2(:);
        % Zpe2 are the temporal 3rd ex. neural populational responses in pre-stimulus duration
        Zpe2 = sum(Z_rate_pe(:,t,:,l_style),1);Zpe2 = Zpe2(:);

        E_XY = mean(Zreal1.*Zreal2); %E(XY)
        E_XY1 = mean(Zreal1.*Zpe2); %E(XY1)
        E_X1Y = mean(Zpe1.*Zreal2); %E(X1Y)
        E_X1Y1 = mean(Zpe1.*Zpe2); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal1) - mean(Zpe1); %E(Z1)
        EZ2 = mean(Zreal2) - mean(Zpe2); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal1,Zpe1); % matrix of Zreal1 and Zpe1
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Zreal2,Zpe2); % matrix of Zreal2 and Zpe2
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'c = ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced 1st and 3rd ex. neural responses');

%% calcuate neural contributions in cue combination

%  correlation coefficients between neural responses and principal components
clear rho
for n_neuron = 1:size(neuralpopulation_rate,2)
    for n_com = 1:size(latent,1)
        rho(n_neuron,n_com) = sqrt(latent(n_com))/sqrt(Sigma(n_neuron,n_neuron))*COEFF(n_neuron,n_com);
    end
end
clear neural_con;
for n_neuron = 1:size(neuralpopulation_rate,2)
    clear squa_rho;
    squa_rho = rho(n_neuron,:).^2;
    neural_con(n_neuron) = squa_rho(1);% neural contributions upon first principal component
    % neural_con(n_neuron) = sum(squa_rho,1:3); % neural contributions upon
    % first three principal components
end

save('neural_con','neural_con');

clear a0;clear b0;clear a1;clear b1;
[a0,b0] = hist(neural_con(:),5);
a1 = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1);
b.FaceColor = ([0.3 0.3 0.3]);hold on;
ylim([0,1.1]);title('Neural contributions in cue combination');

% contributions of ex. neural groups in network responses
neural_group_con_resp = zeros(3,N_neuron);
for n1 = 1:3
    neural_group_con_resp(n1,:) = neural_con(1,((n1-1)*N_neuron+1):(n1*N_neuron));
end

clear a1;
xbin = 0:0.2:1;
for n1 = 1:3
    clear con_resp0;
    con_resp0 = neural_group_con_resp(n1,:);
    [a0,b0] = hist(con_resp0(:),xbin);
    a1(:,n1) = a0./sum(a0);
end
b1 = b0;
figure;
b = bar(b1,a1);
aa = [];
for nn = 1:3
  aa = [aa;'neural group ',num2str(nn)];
  b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
end
legend(aa);
ylim([0,1.1]);title('Contributions of neural groups in cue combination');

%% neural contributions in causal inference

% neural spikes and spiking rates
% 1st ex. neural group
Zleft_spike_real = zeros(N_neuron,L,size(stimulus,2));
Zleft_spiking_real = zeros(N_neuron,L,size(stimulus,2));
% 2nd ex. neural group
Zright_spike_real = zeros(N_neuron,L,size(stimulus,2));
Zright_spiking_real = zeros(N_neuron,L,size(stimulus,2));
% 3rd ex. neural group
Z_spike_real = zeros(N_neuron,L,size(stimulus,2));
Z_spiking_real = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each cause
    for l = 1:L % for each simulation
        clear response0;
        response0 = net.Network_responses{1,l+1}(:,l_style);
        Zleft_spike_real(:,l,l_style) = response0(1:N_neuron,1);
        Zright_spike_real(:,l,l_style) = response0((N_neuron+1):(N_neuron+N_neuron),1);
        Z_spike_real(:,l,l_style) = response0((2*N_neuron+1):(2*N_neuron+N_neuron),1);
        Zleft_spiking_real(:,l,l_style) = response0((3*N_neuron+1):(3*N_neuron+N_neuron),1);
        Zright_spiking_real(:,l,l_style) = response0((3*N_neuron+N_neuron+1):(3*N_neuron+N_neuron+N_neuron),1);
        Z_spiking_real(:,l,l_style) = response0((3*N_neuron+2*N_neuron+1):(3*N_neuron+2*N_neuron+N_neuron),1);
    end
end

% clustering sets
clear networkresponses_cluster;
for m = 1:size(Z_cout_sti,4)
    clear cluster0
    cluster0 = net.action{1,m};
    networkresponses_cluster(:,:,m) = cluster0;
end

% distance of spikes and spiking
Zleft_spike_distance = zeros(N_neuron,size(Zleft_cout_sti,4));Zright_spike_distance = Zleft_spike_distance;Z_spike_distance = Zleft_spike_distance;
Zleft_spiking_distance = Zleft_spike_distance;Zright_spiking_distance = Zright_spike_distance;Z_spiking_distance = Z_spike_distance;
Zleft_spike_contri = Zleft_spike_distance;Zright_spike_contri = Zright_spike_distance;Z_spike_contri = Z_spike_distance;
Zleft_spiking_contri = Zleft_spike_contri;Zright_spiking_contri = Zright_spike_contri;Z_spiking_contri = Z_spike_contri;

% distance induced by spikes of 1st neural group in inference
for m = 1:size(Zleft_cout_sti,4) % for each situation
 for ll = 1:size(Zleft_cout_sti,3) % for each simulation
     clear Zleft_spike_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Zleft_spike_cluster0;
         Zleft_spike_cluster0 = networkresponses_cluster(1:N_neuron,v,m);
         Zleft_spike_distance0(:,v) = Zleft_spike_real(:,ll,m) - Zleft_spike_cluster0;
     end
     Zleft_spike_distance(:,m) = Zleft_spike_distance(:,m) + sum((Zleft_spike_distance0.^2),2);
 end
end

% distance induced by spikes of 2nd neural group in inference
for m = 1:size(Zright_cout_sti,4) % for each situation
 for ll = 1:size(Zright_cout_sti,3) % for each simulation
     clear Zright_spike_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Zright_spike_cluster0;
         Zright_spike_cluster0 = networkresponses_cluster((N_neuron+1):(N_neuron+N_neuron),v,m);
         Zright_spike_distance0(:,v) = Zright_spike_real(:,ll,m) - Zright_spike_cluster0;
     end
     Zright_spike_distance(:,m) = Zright_spike_distance(:,m) + sum((Zright_spike_distance0.^2),2);
 end
end

% distance induced by spikes of 3rd neural group in inference
for m = 1:size(Z_cout_sti,4) % for each situation
 for ll = 1:size(Z_cout_sti,3) % for each simulation
     clear Z_spike_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Z_spike_cluster0;
         Z_spike_cluster0 = networkresponses_cluster((2*N_neuron+1):(2*N_neuron+N_neuron),v,m);
         Z_spike_distance0(:,v) = Z_spike_real(:,ll,m) - Z_spike_cluster0;
     end
     Z_spike_distance(:,m) = Z_spike_distance(:,m) + sum((Z_spike_distance0.^2),2);
 end
end

% distance induced by spiking of 1st neural group in inference
for m = 1:size(Zleft_cout_sti,4) % for each situation
 for ll = 1:size(Zleft_cout_sti,3) % for each simulation
     clear Zleft_spike_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Zleft_spiking_cluster0;
         Zleft_spiking_cluster0 = networkresponses_cluster((3*N_neuron+1):(3*N_neuron+N_neuron),v,m);
         Zleft_spiking_distance0(:,v) = Zleft_spiking_real(:,ll,m) - Zleft_spiking_cluster0;
     end
     Zleft_spiking_distance(:,m) = Zleft_spiking_distance(:,m) + sum((Zleft_spiking_distance0.^2),2);
 end
end

% distance induced by spiking of 2nd neural group in inference
for m = 1:size(Zright_cout_sti,4) % for each situation
 for ll = 1:size(Zright_cout_sti,3) % for each simulation
     clear Zright_spiking_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Zright_spiking_cluster0;
         Zright_spiking_cluster0 = networkresponses_cluster((3*N_neuron+N_neuron+1):(3*N_neuron+N_neuron+N_neuron),v,m);
         Zright_spiking_distance0(:,v) = Zright_spiking_real(:,ll,m) - Zright_spiking_cluster0;
     end
     Zright_spiking_distance(:,m) = Zright_spiking_distance(:,m) + sum((Zright_spiking_distance0.^2),2);
 end
end

% distance induced by spiking of 3rd neural group in inference
for m = 1:size(Z_cout_sti,4) % for each situation
 for ll = 1:size(Z_cout_sti,3) % for each simulation
     clear Z_spiking_distance0;
     for v = 1:size(networkresponses_cluster,2) % for each vector in each clustering martix
         clear Z_spiking_cluster0;
         Z_spiking_cluster0 = networkresponses_cluster((3*N_neuron+2*N_neuron+1):(3*N_neuron+2*N_neuron+N_neuron),v,m);
         Z_spiking_distance0(:,v) = Z_spiking_real(:,ll,m) - Z_spiking_cluster0;
     end
     Z_spiking_distance(:,m) = Z_spiking_distance(:,m) + sum((Z_spiking_distance0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
clear max_distance;clear min_distance;
for m = 1:size(Z_spike_distance,2)%
    clear neural_distance0
    neural_distance0 = [Zleft_spike_distance(:,m),Zright_spike_distance(:,m),Z_spike_distance(:,m),Zleft_spiking_distance(:,m),Zright_spiking_distance(:,m),Z_spiking_distance(:,m)];
    max_distance(m) = max(neural_distance0(:));
    min_distance(m) = min(neural_distance0(:));% common parameters for comparisons
    % contributions of 3 neural groups in identifications upon two
    % situations
    Zleft_spike_contri(:,m) = (max_distance(m) - Zleft_spike_distance(:,m))/(max_distance(m)-min_distance(m));
    Zright_spike_contri(:,m) = (max_distance(m) - Zright_spike_distance(:,m))/(max_distance(m)-min_distance(m));
    Z_spike_contri(:,m) = (max_distance(m) - Z_spike_distance(:,m))/(max_distance(m)-min_distance(m));
    Zleft_spiking_contri(:,m) = (max_distance(m) - Zleft_spiking_distance(:,m))/(max_distance(m)-min_distance(m));
    Zright_spiking_contri(:,m) = (max_distance(m) - Zright_spiking_distance(:,m))/(max_distance(m)-min_distance(m));
    Z_spiking_contri(:,m) = (max_distance(m) - Z_spiking_distance(:,m))/(max_distance(m)-min_distance(m));
end

% contributions of neural spikes and spiking rates in causal inference
for m = 1:size(Z_spike_distance,2) % for each cause
    neural_spike_con_identi = [Zleft_spike_contri(:,m)';Zright_spike_contri(:,m)';Z_spike_contri(:,m)'];
    neural_spiking_con_identi = [Zleft_spiking_contri(:,m)';Zright_spiking_contri(:,m)';Z_spiking_contri(:,m)'];
    clear a1;clear d0;
    d0 = (max(neural_spike_con_identi(:)) - min(neural_spike_con_identi(:)))/5;
    xbin = min(neural_spike_con_identi(:)):d0:max(neural_spike_con_identi(:));
    clear a0;clear a1;clear b0;clear b1;
    [a0,b0] = hist(neural_spike_con_identi(:),xbin);
    a1 = a0./sum(a0);
    b1 = b0;
    figure;
    b = bar(b1,a1,'FaceColor',[0.3,0.3,0.3]*m);
    ylim([0,1.1]);title('Contributions of neural spikes in causal inference');
    clear a1;clear d0;
    d0 = (max(neural_spiking_con_identi(:)) - min(neural_spiking_con_identi(:)))/5;
    xbin = min(neural_spiking_con_identi(:)):d0:max(neural_spiking_con_identi(:));
    clear a0;clear a1;clear b0;clear b1;
    [a0,b0] = hist(neural_spiking_con_identi(:),xbin);
    a1 = a0./sum(a0);
    b1 = b0;
    figure;
    b = bar(b1,a1,'FaceColor',[0.3,0.3,0.3]*m);
    ylim([0,1.1]);title('Contributions of neural spiking rates in causal inference');
end


% Contributions of neural groups in causal inference
for m = 1:size(Z_spike_distance,2) % for each cause
    neural_spike_con_identi = [Zleft_spike_contri(:,m)';Zright_spike_contri(:,m)';Z_spike_contri(:,m)'];
    neural_spiking_con_identi = [Zleft_spiking_contri(:,m)';Zright_spiking_contri(:,m)';Z_spiking_contri(:,m)'];
    clear a1;clear d0;
    d0 = (max(neural_spike_con_identi(:)) - min(neural_spike_con_identi(:)))/5;
    xbin = min(neural_spike_con_identi(:)):d0:max(neural_spike_con_identi(:));
    for n1 = 1:3
     clear con_identi0;
     con_identi0 = neural_spike_con_identi(n1,:);
     [a0,b0] = hist(con_identi0(:),xbin);
     a1(:,n1) = a0./sum(a0);
    end
    b1 = b0;
    figure;
    b = bar(b1,a1);
    aa = [];
    for nn = 1:3
        aa = [aa;'neural group ',num2str(nn)];
        b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
    end
    legend(aa,'Location', 'northwest');
    ylim([0,1.1]);title('Contributions of neural spikes in causal inference');
    clear a1;clear d0;
    d0 = (max(neural_spiking_con_identi(:)) - min(neural_spiking_con_identi(:)))/5;
    xbin = min(neural_spiking_con_identi(:)):d0:max(neural_spiking_con_identi(:));
    for n1 = 1:3
     clear con_identi0;
     con_identi0 = neural_spiking_con_identi(n1,:);
     [a0,b0] = hist(con_identi0(:),xbin);
     a1(:,n1) = a0./sum(a0);
    end
    b1 = b0;
    figure;
    b = bar(b1,a1);
    aa = [];
    for nn = 1:3
        aa = [aa;'neural group ',num2str(nn)];
        b(1,nn).FaceColor = ([0.3 0.3 0.3]*nn);hold on;
    end
    legend(aa,'Location', 'northwest');
    ylim([0,1.1]);title('Contributions of neural spiking rates in causal inference');
end

% clear h;clear p;
% [h,p,ci,stats] = ttest2(Z_contri(:,1),Z_contri(:,2));
% [h,p]

%% neural energy consumption in visual causal inference

for l_style = 1:size(stimulus,2) % for each cause, energy consumption of each neural group
    Z_energy0 = [];Zleft_energy0 = [];Zright_energy0 = [];
    clear iden_time;
    iden_time = net.iden_t(l_style,:);
    for l = 1:L
        [l,iden_time(l)];
        Z_energy0 = [Z_energy0,sum(sum(Z_cout_sti(:,1:iden_time(l),l,l_style),2),1)];
        Zleft_energy0 = [Zleft_energy0,sum(sum(Zleft_cout_sti(:,1:iden_time(l),l,l_style),2),1)];
        Zright_energy0 = [Zright_energy0,sum(sum(Zright_cout_sti(:,1:iden_time(l),l,l_style),2),1)];
    end
end

for l_style = 1:size(stimulus,2) % for each cause, energy consumption of each neural group
    figure;% distribution over simulations
    errorbar(1,mean(Z_energy0(:)),std(Z_energy0(:)),'Color',[0.2,0.2,0.2]);hold on;plot(1,mean(Z_energy0(:)),'o','Color',[0.2,0.2,0.2]);hold on;
    errorbar(2,mean(Zleft_energy0(:)),std(Zleft_energy0(:)),'Color',[0.5,0.5,0.5]);hold on;plot(2,mean(Zleft_energy0(:)),'o','Color',[0.5,0.5,0.5]);hold on;
    errorbar(3,mean(Zright_energy0(:)),std(Zright_energy0(:)),'Color',[0.8,0.8,0.8]);hold on;plot(3,mean(Zright_energy0(:)),'o','Color',[0.8,0.8,0.8]);hold on;
    set(gca,'Xlim',[0 4], 'XTickLabel', '');
end

%% stability of clustering sets over training phase
stability = net.stability;
figure;
for n1 = 1:size(stability,1) % for each causal state
    clear stability0;
    stability0 = stability(n1,:);
    x = 1:size(stability0,2);
    plot(x,stability0,'color',[0.4,0.4,0.4]*n1);hold on;% stability of neural spikes and spiking rates  
end
set(gca,'xlim',[0 size(stability0,2)+1],'ylim',[0 1]);

%% For each downstream neuron, its responsivity is calculated through a Wilcoxon rank-sum test as one attribution
Z_spiketrain_real_avetime = sum(Z_cout_sti,2);
Z_spiketrain_pe_avertime = sum(Z_cout_pre,2);
Z_spiketrain_Wilcoxon_test2 = zeros(size(Z_spiketrain_real_avetime,1),size(Z_spiketrain_real_avetime,4));
for nn = 1:size(Z_spiketrain_real_avetime,1)
    for mm = 1:size(Z_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Z_spiketrain_real_avetime(nn,1,:,mm);
     b = Z_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Z_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end
Zleft_spiketrain_real_avetime = sum(Zleft_cout_sti,2);
Zleft_spiketrain_pe_avertime = sum(Zleft_cout_pre,2);
Zleft_spiketrain_Wilcoxon_test2 = zeros(size(Zleft_spiketrain_real_avetime,1),size(Zleft_spiketrain_real_avetime,4));
for nn = 1:size(Zleft_spiketrain_real_avetime,1)
    for mm = 1:size(Zleft_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Zleft_spiketrain_real_avetime(nn,1,:,mm);
     b = Zleft_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Zleft_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end
Zright_spiketrain_real_avetime = sum(Zright_cout_sti,2);
Zright_spiketrain_pe_avertime = sum(Zright_cout_pre,2);
Zright_spiketrain_Wilcoxon_test2 = zeros(size(Zright_spiketrain_real_avetime,1),size(Zright_spiketrain_real_avetime,4));
for nn = 1:size(Zright_spiketrain_real_avetime,1)
    for mm = 1:size(Zright_spiketrain_real_avetime,4)
    clear a;clear b;
    % for each neuron, a records its responses to sti and b records its
    % spontaneous activities
     a = Zright_spiketrain_real_avetime(nn,1,:,mm);
     b = Zright_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     % neurons with significant responses to sti are selected
     Zright_spiketrain_Wilcoxon_test2(nn,mm) = h*double((mean(a)>0)&&(mean(b)>0));
    end
end

% Neural assembles are determined by the Wilcoxon rank-sum test
Zleft_assembles = cell(3,1);Zright_assembles = cell(3,1);Z_assembles = cell(3,1);
Zleft_assembles = Neuralassemble(Zleft_assembles,Zleft_spiketrain_Wilcoxon_test2);
Zright_assembles = Neuralassemble(Zright_assembles,Zright_spiketrain_Wilcoxon_test2);
Z_assembles = Neuralassemble(Z_assembles,Z_spiketrain_Wilcoxon_test2);


figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Zleft_assembles,1)
            if ~isempty(find(n_neuron == Zleft_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Zright_assembles,1)
         if ~isempty(find(n_neuron == Zright_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
        end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

figure;
shape = ['+','X','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:(net.num_ex_right/20)
     n_neuron = n_neuron + 1;n_assemble0 = 0;% n_assemble0 is number of assembles each neuron belongs to.
     for m = 1:size(Z_assembles,1)
            if ~isempty(find(n_neuron == Z_assembles{m,1}(:)))
               n_assembel = m;
               n_assemble0 = n_assemble0 + 1;
               a = x;b = y;
               if n_assemble0 == 1
                   plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               elseif n_assemble0 > 1
                   plot(a,b,shape(4),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
               end
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

%% Contributions of neural assembles in cue combination
N_assemble = size(Z_assembles,1); % number of neural assembles
% load('neural_con')
% for 1st neural group
neural_contribution_responses_Zleft = [];
clear neural_con0 
neural_con0 = neural_con(1,1:N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Zleft_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron));
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Zleft = [neural_contribution_responses_Zleft,a1];
end
color = [0.3,0.3,0.3];
figure;hold on;
h = bar(neural_contribution_responses_Zleft);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 1st neural group in cue combination');

% for 2nd neural group
neural_contribution_responses_Zright = [];
clear neural_con0 
neural_con0 = neural_con(1,N_neuron+1:2*N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Zright_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron));
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Zright = [neural_contribution_responses_Zright,a1];
end
color = [0.5,0.5,0.5];
figure;hold on;
h = bar(neural_contribution_responses_Zright);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 2nd neural group in cue combination');

% for 3rd neural group
neural_contribution_responses_Z = [];
clear neural_con0 
neural_con0 = neural_con(1,2*N_neuron+1:3*N_neuron);
for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];
        neuron = Z_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        clear a1;
        a1 = mean(neural_con0(1,neuron)); % average 
        if isnan(a1)
            a1 = 0;
        end
        neural_contribution_responses_Z = [neural_contribution_responses_Z,a1];
end
color = [0.7,0.7,0.7];
figure;hold on;
h = bar(neural_contribution_responses_Z);
h.FaceColor = color;
set(gca,'XTickLabel',[]);title('Contributions of neural ensembles in 3rd neural group in cue combination');

%% Contributions of neural assembles in causal inference
N_assemble = size(Z_assembles,1); % number of neural assembles
N_situation = size(Z_rate_real,4); % number of situations
% 1st ex. neural group
clear Neural_assemb_contri_spike_Zleft;clear Neural_assemb_contri_spiking_Zleft;

for n_situation = 1:N_situation
  for n_assemble = 1:N_assemble
    % find series numbers of neurons in each assembles
    neuron = [];
    neuron = Zleft_assembles{n_assemble,1}(:);
    neuron = neuron(neuron>0);
    clear neural_assemb_contri_spike;clear neural_assemb_contri_spiking;
    neural_assemb_contri_spike = Zleft_spike_contri(neuron,n_situation);
    % contributions of neural assemble are averaged over selected PCs and neurons
    Neural_assemb_contri_spike_Zleft(n_situation,n_assemble) = mean(neural_assemb_contri_spike(:));
    neural_assemb_contri_spiking = Zleft_spiking_contri(neuron,n_situation);
    Neural_assemb_contri_spiking_Zleft(n_situation,n_assemble) = mean(neural_assemb_contri_spiking(:));
  end
end
figure;hold on;
h = bar(Neural_assemb_contri_spike_Zleft);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spikes of neural ensembles in 1st neural group in causal inference');

figure;hold on;
h = bar(Neural_assemb_contri_spiking_Zleft);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spiking rates of neural ensembles in 1st neural group in causal inference');

% 2nd ex. neural group
clear Neural_assemb_contri_spike_Zright;clear Neural_assemb_contri_spiking_Zright;

for n_situation = 1:N_situation
  for n_assemble = 1:N_assemble
    % find series numbers of neurons in each assembles
    neuron = [];
    neuron = Zright_assembles{n_assemble,1}(:);
    neuron = neuron(neuron>0);
    clear neural_assemb_contri_spike;clear neural_assemb_contri_spiking;
    neural_assemb_contri_spike = Zright_spike_contri(neuron,n_situation);
    % contributions of neural assemble are averaged over selected PCs and neurons
    Neural_assemb_contri_spike_Zright(n_situation,n_assemble) = mean(neural_assemb_contri_spike(:));
    neural_assemb_contri_spiking = Zright_spiking_contri(neuron,n_situation);
    Neural_assemb_contri_spiking_Zright(n_situation,n_assemble) = mean(neural_assemb_contri_spiking(:));
  end
end
figure;hold on;
h = bar(Neural_assemb_contri_spike_Zright);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spikes of neural ensembles in 2nd neural group in causal inference');

figure;hold on;
h = bar(Neural_assemb_contri_spiking_Zright);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spiking rates of neural ensembles in 2nd neural group in causal inference');

% 3rd ex. neural group
clear Neural_assemb_contri_spike_Z;clear Neural_assemb_contri_spiking_Z;

for n_situation = 1:N_situation
  for n_assemble = 1:N_assemble
    % find series numbers of neurons in each assembles
    neuron = [];
    neuron = Z_assembles{n_assemble,1}(:);
    neuron = neuron(neuron>0);
    clear neural_assemb_contri_spike;clear neural_assemb_contri_spiking;
    neural_assemb_contri_spike = Z_spike_contri(neuron,n_situation);
    % contributions of neural assemble are averaged over selected PCs and neurons
    Neural_assemb_contri_spike_Z(n_situation,n_assemble) = mean(neural_assemb_contri_spike(:));
    neural_assemb_contri_spiking = Z_spiking_contri(neuron,n_situation);
    Neural_assemb_contri_spiking_Z(n_situation,n_assemble) = mean(neural_assemb_contri_spiking(:));
  end
end
figure;hold on;
h = bar(Neural_assemb_contri_spike_Z);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spikes of neural ensembles in 3rd neural group in causal inference');

figure;hold on;
h = bar(Neural_assemb_contri_spiking_Z);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);ylim([0 1.1]);title('Contributions of spiking rates of neural ensembles in 3rd neural group in causal inference');

%% energy consumption of each neural ensemble
for l_style = 1:size(stimulus,2) % for each cause, energy consumption of each neural ensemble
    clear iden_time;
    iden_time = net.iden_t(l_style,:);
    Zleft_ensemble_energy = 0;  % neural ensembles in 1st neural group
    for n_assemble = 1:n_assemble
    neuron = [];
    neuron = Zleft_assembles{n_assemble,1}(:);% find series numbers of neurons in each assembles
     for l = 1:L
        Zleft_ensemble_energy(l,n_assemble) = sum(sum(Zleft_cout_sti(neuron,1:iden_time(l),l,l_style),2),1);
     end
    end

    Zright_ensemble_energy = 0;  % neural ensembles in 2nd neural group
    for n_assemble = 1:N_assemble
    neuron = [];
    neuron = Zright_assembles{n_assemble,1}(:);% find series numbers of neurons in each assembles
     for l = 1:L
        Zright_ensemble_energy(l,n_assemble) = sum(sum(Zright_cout_sti(neuron,1:iden_time(l),l,l_style),2),1);
     end
    end

    Z_ensemble_energy = 0;  % neural ensembles in 3rd neural group
    for n_assemble = 1:N_assemble
    neuron = [];
    neuron = Z_assembles{n_assemble,1}(:);% find series numbers of neurons in each assembles
     for l = 1:L
        Z_ensemble_energy(l,n_assemble) = sum(sum(Z_cout_sti(neuron,1:iden_time(l),l,l_style),2),1);
     end
    end
   
    x_data = [0.9 1 1.1; 1.9 2 2.1; 2.9 3 3.1];
    y_data = [mean(Zleft_ensemble_energy,1);mean(Zright_ensemble_energy,1);mean(Z_ensemble_energy,1)];
    err_data = [std(Zleft_ensemble_energy,1);std(Zright_ensemble_energy,1);std(Z_ensemble_energy,1)];

    figure;
    for i = 1:size(x_data, 1)
      for j = 1:size(x_data, 2)
         plot(x_data(i,j),y_data(i,j),'o','Color',[0.25,0.25,0.25]*j);hold on;
      end
    end
    for i = 1:size(x_data, 1)
      for j = 1:size(x_data, 2)
       h = errorbar(x_data(i,j), y_data(i,j), err_data(i,j),'Color',[0.25,0.25,0.25]*j);hold on;
       if (i == 3)&&(j == 3)
          legend('1st ensemble', '2nd ensemble', '3rd ensemble');
       end
       %set(h, 'Color', colors(i));
      end
    end
    set(gca,'XTickLabel',[]);
end



%% Contributions of overlaps of neural assembles
N_assemble = size(Z_assembles,1); % number of neural assembles
neural_contribution_overlaps_combination = [];
neural_contribution_overlaps_spike_inference = [];
neural_contribution_overlaps_spiking_inference = [];
% load('neural_con')

% for 1st neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,1:N_neuron);
clear neural_overlap1
neural_overlap1 = intersect(Zleft_assembles{1,1}(:),Zleft_assembles{2,1}(:));
neural_contribution_overlaps_combination(1,:) = mean(neural_con0(1,neural_overlap1));
for ii = 1:2
    neural_contribution_overlaps_spike_inference(1,ii) = mean(Zleft_spike_contri(neural_overlap1,ii));
    neural_contribution_overlaps_spiking_inference(1,ii) = mean(Zleft_spiking_contri(neural_overlap1,ii));
end

% for 2nd neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,N_neuron+1:2*N_neuron);
clear neural_overlap2
neural_overlap2 = intersect(Zright_assembles{1,1}(:),Zright_assembles{2,1}(:));
neural_contribution_overlaps_combination(2,:) = mean(neural_con0(1,neural_overlap2));
for ii = 1:2
     neural_contribution_overlaps_spike_inference(2,ii) = mean(Zright_spike_contri(neural_overlap2,ii));
     neural_contribution_overlaps_spiking_inference(2,ii) = mean(Zright_spiking_contri(neural_overlap2,ii));
end

% for 3rd neural group
% overlaps of first two neural assembles
clear neural_con0 
neural_con0 = neural_con(1,2*N_neuron+1:3*N_neuron);
clear neural_overlap3
neural_overlap3 = intersect(Z_assembles{1,1}(:),Z_assembles{2,1}(:));
neural_contribution_overlaps_combination(3,:) = mean(neural_con0(1,neural_overlap3));
for ii = 1:2
     neural_contribution_overlaps_spike_inference(3,ii) = mean(Z_spike_contri(neural_overlap3,ii));
     neural_contribution_overlaps_spiking_inference(3,ii) = mean(Z_spiking_contri(neural_overlap3,ii));
end

N_neuralgroup = 3;
x = 1:N_neuralgroup;
figure;
h = bar(neural_contribution_overlaps_combination,'FaceColor',[0.5,0.5,0.5]);hold on;
xlim([0 4]);title('Contributions of overlaps of neural assembles in cue combination');


figure;hold on;
h = bar(neural_contribution_overlaps_spike_inference);
x = 1:N_situation;
color = [0.4,0.4,0.4;0.8,0.8,0.8];
for mm = 1:N_situation
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
title('Contributions of spikes of overlaps of neural assembles in inference');

figure;hold on;
h = bar(neural_contribution_overlaps_spiking_inference);
x = 1:N_situation;
color = [0.4,0.4,0.4;0.8,0.8,0.8];
for mm = 1:N_situation
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
title('Contributions of spiking of overlaps of neural assembles in inference');
end