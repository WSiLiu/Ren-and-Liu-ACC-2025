function [rate_simulation,cue1] = generate_rate_simulation1(N_cue,noisy_stren,N_neuron,T)
         
         strength = 50;
         clear cue1;
         cue1 = N_cue;

         % cue_tem = 1 indicates ; cue_tem = 2 indicates ;
         % inputs from visual stimuli
         load('visual_sti.mat'); 
         name = 'visual_sti.mat';
         clear name1;clear rate1;
         name1 = ['visualsti',num2str(1)];
         rate1 = cell2mat(struct2cell(load(name,name1)));
         rate_visual = [rate1(:,1);rate1(:,2)];
   
         clear rate_simulation;
         rate_simulation = noisy_stren * rand(N_neuron,2 * T);% basic noisy inputs in simulation
         for t = (T + 1):(2 * T)
             rate_simulation(:,t) = rate_simulation(:,t) + strength*rate_visual;
         end
end