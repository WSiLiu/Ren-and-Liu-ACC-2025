function center = retinalcenter(n,n1,n2,I0,d)

    x0 = floor(n/length(n2))+1*(rem(n,length(n2))~=0);
    x = n1(1,floor(x0));
    y = n2(1,floor(n-length(n2)*(x0-1)));
    x = floor(max(1,min(x,size(I0,2))));y = floor(max(1,min(y,size(I0,1))));
    center = [x,y,x,y];
 end