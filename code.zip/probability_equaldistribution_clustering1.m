function p = probability_equaldistribution_clustering1(observe,clusteringset,p,significance,R,N_cue,N_state)
% N_state = net.N_cuestate;% Each cue has 2 possible states.
% observe = observe(:,find(sum(observe)>0));  %observed data;
% received_distance = zeros(N_cue,N_state);


% For each cue, the likelihood between sample and clustering sets are
% computed.
for j = 1:N_cue
  clear received_distance;clear Received_distance;
  for i = 1:N_state % comparasion between possible states of each cue
  N1 = size(observe,2);N2 = size(clusteringset{j,i},2);
  U = [observe,clusteringset{j,i}];
  Edistance = zeros(1,R);
  for r = 1:R
    clear A1;clear B1;
    A1 = U(:,ceil(size(U,2)*rand(1,N1)));
    B1 = U(:,ceil(size(U,2)*rand(1,N2)));
    Edistance(1,r) = e_distance(A1,B1);
  end
  received_distance(i) = (1-significance)*max(Edistance(1,:));
  end
  Received_distance = (1-significance)*min(received_distance(:));

  for i = 1:N_state
   Edistance1 = zeros(1,R);
   indicator = zeros(1,R);
   N1 = size(observe,2);N2 = size(clusteringset{j,i},2);
   U = [observe,clusteringset{j,i}];
   for r = 1:R
    clear A1;clear B1;
    A1 = U(:,ceil(size(U,2)*rand(1,N1)));
    B1 = U(:,ceil(size(U,2)*rand(1,N2)));
    Edistance1(1,r) = e_distance(A1,B1);
    indicator(1,r) = double(Edistance1(1,r)<=Received_distance);
   end
   p(j,i) = sum(indicator(1,:))/R;
   end
end 


end