function stimulus_modification_assemble_response(N_situation,N_assemble,rate,assembles)
clear Z_responses;
for nn = 1:N_situation
    clear Zleft_responses0;
    Zleft_responses0 = rate(:,:,:,nn);
    Z_responses(:,nn) = mean(mean(Zleft_responses0,2),3);
end
MI_assemble = cell(N_assemble,1);
N = 0;clear a1;clear b1;
for n1 = 1:N_assemble
    clear neurons;clear Z_assemble_responses;
    neurons = assembles{n1,1};
    if ~isempty(neurons)
    N = N + 1;
    Z_assemble_responses = Z_responses(neurons,:);
    MI_assemble0 = [];
    for nn1 = 1:size(Z_assemble_responses,1)% for each neuron in assemble
        if (Z_assemble_responses(nn1,1) + Z_assemble_responses(nn1,2)) == 0
            MI_assemble0(nn1,1) = 0;
        else
            MI_assemble0(nn1,1) = (Z_assemble_responses(nn1,1) - Z_assemble_responses(nn1,2))./(Z_assemble_responses(nn1,1) + Z_assemble_responses(nn1,2));
        end
    end
    MI_assemble{n1,1} = MI_assemble0(:);
    [a0,b0] = hist(MI_assemble{n1,1}(:));
    a1(:,n1) = a0./sum(a0);
    b1(:,n1) = b0;
    end
end

figure;
for n1 = 1:size(a1,2)
    a0 = a1(:,n1);b0 = b1(:,n1);
    subplot(1,N,n1);bar(b0,a0,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);hold on;
end




end