function p = neural_correlation(N_situation,T1,spikes1,spikes2)
 clear p;
 for l_style = 1:N_situation
    for t = 1:T1
        clear Z1;clear Z2;clear Cov_XY;clear std_X;clear std_Y;
        Z1 = spikes1(1,t,:,l_style);
        Z2 = spikes2(1,t,:,l_style);
        Cov_XY = cov(Z2(:),Z1(:));
        std_Y = std(Z2(:));
        std_X = std(Z1(:));
        p(t,l_style) = Cov_XY(2,1)/(std_X*std_Y);
    end
 end
end