function Plot_neural_assemble_energy(Energy_assemble)
N_assemble = size(Energy_assemble,1);N_situation = 2;
figure;clear MI_energy;
for nn1 = 1:N_assemble
    for nn2 = 1:N_assemble
        for nn3 = 1:2
        n_situation = 1;% in 1st situation
        energy_assemble1 = Energy_assemble(nn1,nn2,n_situation,nn3);% between nn1 and nn2 in two groups
        n_situation = 2;% in 2nd situation
        energy_assemble2 = Energy_assemble(nn1,nn2,n_situation,nn3);
        MI_energy(nn1,nn2) = (energy_assemble1 - energy_assemble2)/(energy_assemble1 + energy_assemble2);
        if MI_energy(nn1,nn2)>=0 
            type = 'o';
        else
            type = '*';
        end
        plot3(nn1,nn2,MI_energy(nn1,nn2),type,'color',[0.3 0.3 0.3]*nn3,'MarkerSize',15);hold on;
        end
    end
end
grid on;zlim([-1.1*max(abs(MI_energy(:))) 1.1*max(abs(MI_energy(:)))]);

xlim([0.5 3.5]);ylim([0.5 3.5]);
% xticks([1 2 3]);yticks([1 2 3]);
end