function [DVA,stability] = DVA_neuralspike(neural_spikes)
spikes1 = zeros(size(neural_spikes,1),1);
   for t = 1:size(neural_spikes,2)
        spike0 = neural_spikes(:,t);
        if sum(spike0(:)) ~= 0
        spikes1 = spikes1 + spike0./norm(spike0,2);
        end
   end
   DVA = 1 - norm(spikes1,2)/size(neural_spikes,2);
   stability = 1 - DVA;
end