function [patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,hidden_cue] = generate_patterns2(stimulus,T,N_cue)
% paired stimuli are visual and sound stimuli
pat_sequences = cell(1,1);
patterns = cell(1,1);
pat_labels = cell(1,1);
pat_seq0 = [];
R0 = [];
cue0 = [];
noisy_stren = 1; % stength of noisy signal

load('visual_sti.mat');
name = 'visual_sti.mat';
name1 = ['time',num2str(1),num2str(1),num2str(1)];
rate1 = cell2mat(struct2cell(load(name,name1)));
N_neuron = size(rate1,1);


for n_stimulus = 1:length(stimulus)% design stimuli for each simulation
    pat_seq = n_stimulus;
    rate = [];
    % There are two cues in each simulation, one is temporal and the other is spatial
    cue_tem = double(rand(1,1)>0.5) + 1; % determine the temporal cue of the stimuli, randomly
    cue_spatial = 1; % the spacial cue of the stimuli is given and fixed

    clear rate_simulation;clear cue;
    [rate_simulation,cue] = generate_rate_simulation2(cue_tem,cue_spatial,noisy_stren,N_neuron,T);

    rate = [rate,rate_simulation];
    R0 = [R0,rate];
    pat_seq0 = [pat_seq0,pat_seq];
    cue0 = [cue0,cue];
end
r_duration2 = zeros(2 * N_neuron,2 * T);
R0 = [r_duration2,R0];
pat_seq0 = [(-1)*ones(size(pat_seq0,1),1),pat_seq0];% the cue of the blank duration is -1 and has no meaning
cue0 = [(-1)*ones(size(cue0,1),1),cue0]; % cue returns the sequence of values of cue
R0 = 10*R0.*double(R0>0);
num_inputs = size(R0,1);

pat_sequences{1,1} = pat_seq0;
patterns{1,1} = R0;
pat_labels{1,1} = num2str(1);
free_pat_sequences = pat_sequences;
hidden_cue = cue0;   

    
end