function [y,e,MI_complex] = assembles_spiking_complex(spikes1,spikes2,spikes3,assembles1,assembles2,assembles3)
% spikes = [spikes1,spikes2,spikes3];
assembles = [assembles1,assembles2,assembles3];

N_situation = size(spikes1,4);
N_assemble = size(assembles,1);
N_group = 3;
L = size(spikes1,3);
spikes = [];
for nn = 1:N_group
    if nn == 1
        spikes(:,:,:,:,nn) = spikes1;
    elseif nn == 2
        spikes(:,:,:,:,nn) = spikes2;
    else
        spikes(:,:,:,:,nn) = spikes3;
    end
end

% complex of spiking train is collected over assembles to situations
y = [];e = [];% y is mean, z is std
for n2 = 1:N_situation
   for n5 = 1:N_group
    for n1 = 1:N_assemble
    neuron1 = assembles{n1,n5};
        complex0 = [];complex1 = [];
        for n3 = 1:length(neuron1)
          for n4 = 1:L
            clear spike_train;
            spike_train = spikes(n3,:,n4,n2,n5);
            [C1, ~] = calc_lz_complexity(spike_train, 'exhaustive', 1);
            complex0(n3,n4) = C1;
          end
        end
        complex1 = sum(complex0,1);
        y(n5,n1,n2) = mean(complex1);
        e(n5,n1,n2) = std(complex1);
        % y(n2,n1,n5) = complex(n1,n2,1);
        % e(n2,n1,n5) = complex(n1,n2,2);
    end
   end
end

x = 1:size(y,2);
for n1 = 1:size(y,3)
figure;
if n1 == 1
    type0 = 'o';
else
    type0 = '*';
end
for n5 = 1:3
    plot(x,y(n5,:,n1),type0,'color',[0.25 0.25 0.25]*n5);hold on;
    errorbar(x, y(n5,:,n1), e(n5,:,n1),'color',[0.25 0.25 0.25]*n5);hold on;
    xlim([0.5 3.5]);
    xticks([1 2 3]);
end
end

MI_complex = [];
for n2 = 1:N_group
    for n3 = 1:N_assemble
        MI_complex(n2,n3) = (y(n2,n3,1) - y(n2,n3,2))/(y(n2,n3,1) + y(n2,n3,2));
    end
end

figure; 
top1 = 1.1*max(abs(MI_complex(:)));bottom1 = -top1;
x = 1:N_group;
y = 1:N_assemble;
for n2 = 1:3
    for n3 = 1:3
        if MI_complex(n2,n3) > 0
            type1 = 'o';
        else
            type1 = '*';
        end
        plot3(x(n2),y(n3),MI_complex(n2,n3),type1,'Markersize',15,'Color',[0.5 0.5 0.5]);hold on
    end
end
grid on;
xlim([0.5 3.5]);ylim([0.5 3.5]);
xticks([1 2 3]);yticks([1 2 3]);


end